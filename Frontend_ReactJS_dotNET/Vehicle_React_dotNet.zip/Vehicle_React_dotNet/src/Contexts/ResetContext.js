import { createContext } from "react";

export const ResetContext = createContext({});
